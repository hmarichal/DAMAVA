#define CUENTA 10



void Timer_SetFlag(int* flag_timeout_main);
void Timer_Init(void);
