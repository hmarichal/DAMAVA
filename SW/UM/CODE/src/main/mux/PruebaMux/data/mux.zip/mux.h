#ifndef MUX_H
#define MUX_H

#include <Arduino.h>

void Mux_Init();
void Mux_SeleccionarCuarto(char);


#endif
