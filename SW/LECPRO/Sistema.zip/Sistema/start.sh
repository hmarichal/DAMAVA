#!/bin/bash
#ejecuta los script del sistema


python servidorUM.py 98:D3:31:FB:57:EF 1
