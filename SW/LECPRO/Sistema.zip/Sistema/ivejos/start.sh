#!/bin/bash
#ejecuta los script del sistema


python sifones.py 98:D3:31:FB:57:EF 1 t
#python servidorUM2.py 3C:A1:0D:DD:97:8F 2 t


